def test1():
    print("test1 function works!")